﻿-- Author      : Mimma
-- Create Date : 4/3/2016 11:53:48 AM

local CHAT_END					= "|r"
local COLOUR_INTRO				= "|c80F0F0F0"
local COLOUR_CHAT				= "|c80F0F020"

local PARTY_CHANNEL				= "PARTY"
local RAID_CHANNEL				= "RAID"
local YELL_CHANNEL				= "YELL"
local SAY_CHANNEL				= "SAY"
local WARN_CHANNEL				= "RAID_WARNING"
local GUILD_CHANNEL				= "GUILD"
local WHISPER_CHANNEL			= "WHISPER"


--	Settings (to be made configurable)
local CONFIG_USE_GUILDNOTES		= false
local CONFIG_MINBID_STRATEGY	= 1

--	State machine:
local STATE_NONE				= 0
local STATE_AUCTION_RUNNING		= 10
local STATE_AUCTION_PAUSED		= 20
local STATE_AUCTION_COMPLETE	= 30
local STATE_PAUSED				= 90

-- An action runs for a minimum of 20 seconds, and minimum 5 seconds after a new bid is received
local TIME_STATE_AUCTION		= 20
local TIME_STATE_EXTENSION		= 8

local RAID_STATE_DISABLED		= 0
local RAID_STATE_ENABLED		= 1

-- Max # of bids shown in the AuctionUI
local MAX_BIDS					= 10
-- List of valid bids: { Name, DKP }
local Bids = { }

-- true if a job is already running
local JobIsRunning				= false


-- Working variables:
local RaidState					= RAID_STATE_DISABLED
local AuctionedItemLink			= ""
local AuctionState				= STATE_NONE

-- Raid Roster: table of raid players:		{ Name, DKP, Class, Rank, Online }
local RaidRosterTable			= { }
-- Guild Roster: table of guild players:	{ Name, DKP, Class, Rank, Online }
local GuildRosterTable			= { }
local RaidRosterLazyUpdate		= false;

--	List of {jobname,name,dkp} tables
local JobQueue					= { }


GBAY_UseOfficerNotes = false;
GBAY_AuctionMinimumIncrease = 1.10;



local QUALITY_COLORS = {
	{0, "Poor",			{ 157,157,157 } },	--9d9d9d
	{1, "Common",		{ 255,255,255 } },	--ffffff
	{2, "Uncommon",		{  30,255,  0 } },	--1eff00
	{3, "Rare",			{   0,112,255 } },	--0070ff
	{4, "Epic",			{ 163, 53,238 } },	--a335ee
	{5, "Legendary",	{ 255,128,  0 } }	--ff8000
}

local CLASS_COLORS = {
	{ "Druid",			{ 255,125, 10 } },	--255 	125 	10		1.00 	0.49 	0.04 	#FF7D0A
	{ "Hunter",			{ 171,212,115 } },	--171 	212 	115 	0.67 	0.83 	0.45 	#ABD473 
	{ "Mage",			{ 105,204,240 } },	--105 	204 	240 	0.41 	0.80 	0.94 	#69CCF0 
	{ "Paladin",		{ 245,140,186 } },	--245 	140 	186 	0.96 	0.55 	0.73 	#F58CBA
	{ "Priest",			{ 255,255,255 } },	--255 	255 	255 	1.00 	1.00 	1.00 	#FFFFFF
	{ "Rogue",			{ 255,245,105 } },	--255 	245 	105 	1.00 	0.96 	0.41 	#FFF569
	{ "Shaman",			{ 245,140,186 } },	--245 	140 	186 	0.96 	0.55 	0.73 	#F58CBA
	{ "Warlock",		{ 148,130,201 } },	--148 	130 	201 	0.58 	0.51 	0.79 	#9482C9
	{ "Warrior",		{ 199,156,110 } }	--199 	156 	110 	0.78 	0.61 	0.43 	#C79C6E
}


--
--	SLASH COMMANDS
--

--[[
--	/startauction <item>
--	/gbay <item>
--]]
SLASH_GBAY_STARTAUCTION1 = "/startauction"
SLASH_GBAY_STARTAUCTION2 = "/gbay"
SlashCmdList["GBAY_STARTAUCTION"] = function(msg)
	if GBAY_IsInRaid(true) then
		RaidState = RAID_STATE_ENABLED;
		
		GBAY_AddJob( function(job) GBAY_StartAuction(job[2]) end, msg, "_" )
		GBAY_RequestUpdateGuildRoster();
	end
end


-- /stopauction, /cancelauction






--[[
	Echo a message for the local user only, including "logo"
]]
local function echo(msg)
	if msg then
		DEFAULT_CHAT_FRAME:AddMessage(COLOUR_CHAT .. msg .. CHAT_END)
	end
end

local function gEcho(msg)
	echo("<"..COLOUR_INTRO.."gBay"..COLOUR_CHAT.."> "..msg);
end

local function rwEcho(msg)
	SendChatMessage(msg, WARN_CHANNEL);
end

local function raidEcho(msg)
	SendChatMessage(msg, RAID_CHANNEL);
end

local function whisper(receiver, msg)
	SendChatMessage(msg, WHISPER_CHANNEL, nil, receiver);
end




local function getQualityColor(quality)
	for n=1, table.getn(QUALITY_COLORS), 1 do
		local q = QUALITY_COLORS[n];
		if q[1] == quality then
			return q[3]
		end
	end
	
	-- Unknown quality code; can't happen! Let's just return poor quality!
	return QUALITY_COLORS[1][3];
end



--[[
	Convert a msg so first letter is uppercase, and rest as lower case.
]]
local function UCFirst(msg)
	if not msg then
		return ""
	end	

	local f = string.sub(msg, 1, 1)
	local r = string.sub(msg, 2)
	return string.upper(f) .. string.lower(r)
end




--
--	PROPERTIES
--

function GBAY_GetSecondCounter()
	return Seconds;
end

function GBAY_GetAuctionState()
	return AuctionState;
end

function GBAY_SetAuctionState(auctionState, seconds)
	if not seconds then
		seconds = 0;
	end
	AuctionState = auctionState;
	GBAY_setSecondCounter(seconds);
end




--[[
	Start the auction, and set state to STATE_STARTING
	Parameters:
	itemLink: a blizzard itemlink to auction.
	Since 0.0.1
]]
function GBAY_StartAuction(itemLink)
	echo("In GBAY_StartAuction, itemlink=".. itemLink);

	-- Extract ItemId from itemLink string:
	local _, _, itemId = string.find(itemLink, "item:(%d+):")
	if not itemId then
		gEcho("Item was not found: ".. itemLink);
		return;
	end	
	
	AuctionedItemLink = itemLink;

	local itemName, _, itemQuality, _, _, _, _, _, itemTexture = GetItemInfo(itemId);	
	
	local frame = getglobal("AuctionUIFrameItem");
	if frame then
		local rgb = getQualityColor(itemQuality);	
		local inf = getglobal(frame:GetName().."ItemName");
		inf:SetText(itemName);
		inf:SetTextColor( (rgb[1]/255), (rgb[2]/255), (rgb[3]/255), 1);
		
		local tf = getglobal(frame:GetName().."ItemTexture");
		if tf then
			tf:SetTexture(itemTexture);
		end
	end
	
	Bids = { }
	GBAY_UpdateBidElements();
	GBAY_OpenAuctionUI();
	
	GBAY_SetAuctionState(STATE_AUCTION_RUNNING, TIME_STATE_AUCTION);
end



local EventTime = 0;
local TimerTick = 0;
local Secounds = 0;

function GBAY_setSecondCounter(seconds)
	Seconds = seconds;
end

function GBAY_OnTimer(elapsed)
	TimerTick = TimerTick + elapsed

	if floor(EventTime) < floor(TimerTick) then
		GBAY_checkAuctionState();
		EventTime = TimerTick;
	end
end



--[[
	The big gBay state machine.
	Since 0.0.1
]]
function GBAY_checkAuctionState()
	local state = GBAY_GetAuctionState();
	
	if state == STATE_NONE or state == STATE_AUCTION_PAUSED then
		-- Just idling ...
		return;
	end
		
	if state == STATE_AUCTION_RUNNING then
		local secs = GBAY_GetSecondCounter();
		if secs == TIME_STATE_AUCTION then
			rwEcho(string.format("Auction open for %s", AuctionedItemLink));
			rwEcho(string.format("/w %s bid [your bid]", UnitName("Player")))
		end
		
		if secs == 10 then
			rwEcho(string.format("10 seconds left - /w %s bid [your bid]", UnitName("Player")));
		end
		if secs == 3 then
			rwEcho("3 seconds left");
		end
		if secs == 2 then
			rwEcho("2 seconds left");
		end
		if secs == 1 then
			rwEcho("1 second left");
		end
		if secs < 1 then
			-- Time is up - complete the auction:
			GBAY_FinishAuction(sender, dkp);	
		end
				
		Seconds = Seconds - 1;
	end
	
	if state == STATE_COMPLETE then
		--	 We're idle
		state = STATE_NONE;
	end

	GBAY_RefreshButtonStates();
end






--[[
--	There's a message in the Guild channel - investigate that!
--]]
function GBAY_HandleGuildChatMessage(event, message, sender)
	echo(string.format("Guild: %s --> %s", sender, message));
end

--[[
--	There's a message in the Raid channel - investigate that!
--]]
function GBAY_HandleRaidChatMessage(event, message, sender)
	if not message or message == "" or not string.sub(message, 1, 1) == "!" then
		return;
	end
	
	local command = string.sub(message, 2)

	GBAY_OnChatWhisper(event, command, sender);
end


--[[
--	Handle incoming chat whisper.
--	Guild and Raid "!" commands are redirected here too with the "raw" command line.
--	Since 0.1.0
--]]
function GBAY_OnChatWhisper(event, message, sender)	
	
	local _, _, cmd = string.find(message, "(%a+)");	
	cmd = string.lower(cmd);
	
	if cmd == "bid" then
		GBAY_HandlePlayerBid(sender, cmd);
	elseif cmd == "queue" then
		GBAY_HandleQueueRequest(sender, cmd);
	end
end	



--[[
--	Handle incoming bid request.
--	Since 0.0.1
--]]
function GBAY_HandlePlayerBid(sender, message)
	local playerInfo = GBAY_GetGuildPlayerInfo(sender);
	if not playerInfo then
		whisper(sender, "You need to be in the guild for bidding!");
		return;
	end

	local availableDkp = 1 * (playerInfo[2]);
	local minimumBid = GBAY_GetMinimumBid();
	
	local _, _, dkp = string.find(message, "bid\ (%d+)")
	if not dkp then
		-- This could still be a "min" or "max" bid; try that:
		if message == "bid min" then
			dkp = minimumBid
		elseif message == "bid max" then
			dkp = availableDkp
		end
		
		if not dkp then
			-- This was not following a legal format; skip message
			return;
		end
	end
	
	dkp = 1 * dkp


	local unitId = GBAY_GetUnitIDFromGroup(sender);
	if not unitId then
		-- The sender of the message was not in the raid; must be a normal whisper.
		return;
	end

	if not (AuctionState == STATE_AUCTION_RUNNING) then
		whisper(sender, "There is currently no auction running - bid was ignored.");
		return;
	end	


	if dkp < minimumBid then
		whisper(sender, string.format("You must bid at least %s DKP - bid was ignored.", minimumBid));
		return;
	end

	if availableDkp < dkp then
		whisper(sender, string.format("You only have %d DKP - bid was ignored.", availableDkp));
		return
	end
	
	if Seconds < TIME_STATE_EXTENSION then
		Seconds = TIME_STATE_EXTENSION;
	end
	
	local bidderClass = playerInfo[3];
	local bidderRank  = playerInfo[4];
	
	rwEcho(string.format("%s is bidding %d DKP for %s", sender, dkp, AuctionedItemLink));

	GBAY_RegisterBid(sender, dkp, bidderClass, bidderRank);
	
		
	-- Checks to perform now:
	-- * Do user have enough DKP?	(Done)
	-- * Do user bid <minimum dkp>? (Done)
	--		* exception: if he goes all out he is allowed to go below minimum dkp
	-- * Is user already the highest bidder? (should we let users screw up? I personally think so!)


	-- TODO:
	-- Hide incoming whispers for local player (how?)		
end



function GBAY_RegisterBid(playername, bid, playerclass, rank)
	whisper(playername, string.format("Your bid of %d DKP has been registered.", bid) );

	Bids = GBAY_RenumberTable(Bids);
	
	Bids[table.getn(Bids) + 1] = { playername, bid, playerclass, rank };

	GBAY_SortTableDescending(Bids, 2);
	
	--Debug output:
	-- for n=1, table.getn(Bids), 1 do
		-- local cbid = Bids[n];
		-- local name = cbid[1];
		-- local dkp  = cbid[2];
		-- local clss = cbid[3];
		-- local rank = cbid[4];
		-- echo(string.format("%d - %s bid %d DKP, class=%s, rank=%s", n, name, dkp, clss, rank));
	-- end
 
	GBAY_UpdateBidElements();
end


function GBAY_UnregisterBid(playername, bid)
	playername = GBAY_UCFirst(playername);
	bid = 1 * bid;

	local bidInfo;
	for n=1,table.getn(Bids), 1 do
		bidInfo = Bids[n];
		if bidInfo[1] == playername and 1*(bidInfo[2]) == bid then
			table.remove(Bids, n);

			GBAY_UpdateBidElements();
			GBAY_ShowSelectedPlayer();
			
			return;
		end
	end
end

function GBAY_GetBidInfo(playername, bid)
	playername = GBAY_UCFirst(playername);
	bid = 1 * bid;

	local bidInfo;
	for n=1,table.getn(Bids), 1 do
		bidInfo = Bids[n];
		if bidInfo[1] == playername and 1*(bidInfo[2]) == bid then
			return bidInfo;
		end
	end

	return nil;
end

function GBAY_RenumberTable(sourcetable)
	local index = 1;
	local temptable = { };
	for key,value in ipairs(sourcetable) do
		temptable[index] = value;
		index = index + 1
	end
	return temptable;
end

function GBAY_SortTableDescending(sourcetable, index)
	local doSort = true
	while doSort do
		doSort = false
		for n=1,table.getn(sourcetable) - 1,1 do
			local a = sourcetable[n]
			local b = sourcetable[n + 1]
			if tonumber(a[index]) and tonumber(b[index]) and tonumber(a[index]) < tonumber(b[index]) then
				sourcetable[n] = b
				sourcetable[n + 1] = a
				doSort = true
			end
		end
	end
end

function GBAY_AcceptBid(playername, bid)
	if playername and bid then
		playername = GBAY_UCFirst(playername);
		bid = 1 * bid;
	
		AuctionUIFrame:Hide();
		
		rwEcho(string.format("%s sold to %s for %d DKP.", AuctionedItemLink, playername, bid));
		
		GBAY_SubtractDKP(playername, bid);		
	end
end


--
--	Player Raid Queue functions
--
function GBAY_HandleQueueRequest(sender, message)

	echo(string.format("Queue request: %s --> %s", sender, message));

end





--
--	UI functions
--

function GBAY_OpenAuctionUI()
	AuctionUIFrame:Show();
end

function GBAY_InitializeBidElements()
	for n=1, MAX_BIDS, 1 do
		local entry = CreateFrame("Button", "$parentEntry"..n, AuctionUIFrameTableList, "GBAY_CellTemplate");
		entry:SetID(n);
		if n == 1 then
			entry:SetPoint("TOPLEFT", 4, -4);
		else
			entry:SetPoint("TOP", "$parentEntry"..(n-1), "BOTTOM");
		end
	end
end

--	Show top <n> in bid window
function GBAY_UpdateBidElements()
	local bidder, bid, playerclass, rank;
	for n=1, MAX_BIDS, 1 do
		if table.getn(Bids) < n then
			bidder = "";
			bid = "";
			playerclass = "";
			rank = "";
		else
			local cbid = Bids[n];
			bidder = cbid[1];
			bid = string.format("%d", cbid[2]);
			playerclass = cbid[3];
			rank = cbid[4];
		end

		local color = GBAY_GetClassColorCodes(playerclass);

		local frame = getglobal("AuctionUIFrameTableListEntry"..n);
		getglobal(frame:GetName().."Bidder"):SetText(bidder);
		getglobal(frame:GetName().."Bidder"):SetTextColor((color[1]/255), (color[2]/255), (color[3]/255), 255);
		getglobal(frame:GetName().."Bid"):SetText(bid);
		getglobal(frame:GetName().."Rank"):SetText(rank);

		GBAY_RefreshButtonStates();
		frame:Show();
	end
end


function GBAY_GetSelectedBid()
	local selectedBid = nil;
	
	local frame = getglobal("AuctionUIFrameSelected");
	local bidder = getglobal(frame:GetName().."Bidder"):GetText();
	local bid = getglobal(frame:GetName().."Bid"):GetText();

	if bidder and bid then
		selectedBid = { bidder, bid };
	end

	return selectedBid;
end

--[[
--	Refresh button states
--]]
function GBAY_RefreshButtonStates()
	local isAuctionRunning = (GBAY_GetAuctionState() == STATE_AUCTION_RUNNING);
	local isAuctionPaused = (GBAY_GetAuctionState() == STATE_AUCTION_PAUSED);

	local isBidderSelected = true;
	local selectedBid = GBAY_GetSelectedBid();
	if not selectedBid then
		isBidderSelected = false;
	end	

	if isBidderSelected then
		if isAuctionRunning or isAuctionPaused then
			getglobal("AcceptBidButton"):Disable();
		else
			getglobal("AcceptBidButton"):Enable();
		end		
		getglobal("CancelBidButton"):Enable();
	else
		getglobal("AcceptBidButton"):Disable();
		getglobal("CancelBidButton"):Disable();
	end
	
	if isAuctionRunning or isAuctionPaused then
		getglobal("CancelAuctionButton"):Enable();
		getglobal("RestartAuctionButton"):Enable();
		getglobal("FinishAuctionButton"):Enable();
		if isAuctionPaused then
			getglobal("PauseAuctionButton"):Enable();
			getglobal("PauseAuctionButton"):SetText("Resume Auction");
		else
			getglobal("PauseAuctionButton"):Enable();
			getglobal("PauseAuctionButton"):SetText("Pause Auction");
		end
	else
		getglobal("CancelAuctionButton"):Disable();
		getglobal("RestartAuctionButton"):Enable();
		getglobal("FinishAuctionButton"):Disable();
		getglobal("PauseAuctionButton"):Disable();
		getglobal("PauseAuctionButton"):SetText("Pause Auction");
	end	
end


--[[
--	Accept a player bid
--	Since 0.0.3
--]]
function GBAY_AcceptSelectedPlayerBid()
	local selectedBid = GBAY_GetSelectedBid();
	if not selectedBid then
		return;
	end

	GBAY_AcceptBid(selectedBid[1], selectedBid[2]);
end


--[[
--	Cancel a player bid
--	Since 0.0.3
--]]
function GBAY_CancelSelectedPlayerBid()
	local selectedBid = GBAY_GetSelectedBid();
	if not selectedBid then
		return;
	end
	
	GBAY_UnregisterBid(selectedBid[1], selectedBid[2]);
end


--[[
--	Pause the Auction
--	Since 0.0.3
--]]
function GBAY_PauseAuction()
	local state = GBAY_GetAuctionState();	
	local secs = GBAY_GetSecondCounter();
	
	if state == STATE_AUCTION_RUNNING then
		GBAY_SetAuctionState(STATE_AUCTION_PAUSED, secs);
		rwEcho("Auction have been Paused");
	end
	
	if state == STATE_AUCTION_PAUSED then
		GBAY_SetAuctionState(STATE_AUCTION_RUNNING, secs + TIME_STATE_EXTENSION);
		rwEcho("Auction have been Resumed");
	end

	GBAY_RefreshButtonStates();
end


--[[
--	Finish the Auction
--	Since 0.0.3
--]]
function GBAY_FinishAuction()
	local state = GBAY_GetAuctionState();
	if state == STATE_AUCTION_RUNNING or state == STATE_AUCTION_PAUSED then
		rwEcho(string.format("Auction for %s is over", AuctionedItemLink));
		GBAY_SetAuctionState(STATE_AUCTION_COMPLETE);
		
		-- Check if a player was selected; if not, select highest bid:
		if table.getn(Bids) > 0 then
			local selectedBid = GBAY_GetSelectedBid();
			if not selectedBid then
				GBAY_ShowSelectedPlayer(Bids[1][1], Bids[1][2]);
			end
		end
	end
	
	GBAY_RefreshButtonStates();
end

--[[
--	Cancel the Auction
--	Since 0.0.3
--]]
function GBAY_CancelAuction()
	local state = GBAY_GetAuctionState();
	if state == STATE_AUCTION_RUNNING or state == STATE_AUCTION_PAUSED then
		Bids = { }
		GBAY_SetAuctionState(STATE_AUCTION_NONE);
		rwEcho("Auction was Cancelled");		
	end
end


--[[
--	Restart the Auction
--	Since 0.0.3
--]]
function GBAY_RestartAuction()
	GBAY_SetAuctionState(STATE_NONE);		
	GBAY_StartAuction(AuctionedItemLink);
end



--[[
--	Show the selected (clicked) bidder information in AuctionUI.
--	Since 0.0.2
--]]
function GBAY_ShowSelectedPlayer(playername, bid)
	local bidInfo = nil
	if playername and bid then
		bidInfo = GBAY_GetBidInfo(playername, bid);	
	end
	
	local bidder, bid, playerclass, rank;
	if not bidInfo then
		bidder = "";
		bid = "";
		playerclass = "";
		rank = "";
	else
		bidder = bidInfo[1];
		bid = string.format("%d", bidInfo[2]);
		playerclass = bidInfo[3];
		rank = bidInfo[4];
	end
	
	local color = GBAY_GetClassColorCodes(playerclass);

	local frame = getglobal("AuctionUIFrameSelected");
	getglobal(frame:GetName().."Bidder"):SetText(bidder);
	getglobal(frame:GetName().."Bidder"):SetTextColor((color[1]/255), (color[2]/255), (color[3]/255), 255);
	getglobal(frame:GetName().."Bid"):SetText(bid);
	getglobal(frame:GetName().."Rank"):SetText(rank);

	GBAY_RefreshButtonStates();
end


function GBAY_GetClassColorCodes(classname)
	local colors = { 128,128,128 }
	classname = GBAY_UCFirst(classname);

	local cc;
	for n=1, table.getn(CLASS_COLORS), 1 do
		cc = CLASS_COLORS[n];
		if cc[1] == classname then
			return cc[2];
		end
	end

	return colors;
end


--[[
	Convert a msg so first letter is uppercase, and rest as lower case.
]]
function GBAY_UCFirst(msg)
	if not msg then
		return ""
	end	

	local f = string.sub(msg, 1, 1)
	local r = string.sub(msg, 2)
	return string.upper(f) .. string.lower(r)
end



--
--	DKP functions
--

--[[
	Get DKP belonging to a specific player.
	Returns NIL if player was not found. Players with no DKP will return 0.
]]
function GBAY_GetDKP(playername)
	local dkp = nil;
	local playerInfo = GBAY_GetGuildPlayerInfo(playername);
	if playerInfo then
		dkp = 1 * (playerInfo[2]);
	end
	
	return dkp;
 end


--[[
--	Subtract <dkp> DKP from <playername>
--]]
function GBAY_SubtractDKP(playername, dkp)
	echo(string.format("Subtract %d DKP from %s", dkp, playername));
end


--[[
	Get information belonging to a specific player in the guild.
	Returns NIL if player was not found.
]]
function GBAY_GetGuildPlayerInfo(player)
	local memberCount = GetNumGuildMembers()
	local playerInfo = nil

	for n=1,memberCount,1 do
		--	TODO: Cache the GuildRoster just like the RaidRoster
		local dkpValue = 0;
		local name, rank, _, _, playerclass, _, publicNote, officerNote = GetGuildRosterInfo(n)
		if name == player then
			local note = officerNote
			if CONFIG_USE_GUILDNOTES then
				note = publicNote
			end
			local _, _, dkp = string.find(note, "<(-?%d*)>")

			if dkp and tonumber(dkp)  then
				dkpValue = (1 * dkp)
			end
			
			playerInfo = { player, dkpValue, playerclass, rank }
		end
   	end
   	
   	return playerInfo;
end





--
--	MinBidStrategy
--
local function strategy10Percent(dkp)
	return 1.10 * dkp;
end

function GBAY_GetHighestBid()
	local highestBid = nil;
	
	if table.getn(Bids) > 0 then
		highestBid = Bids[1];
	end

	return highestBid;
end


function GBAY_GetMinimumBid()
	local minimumBid = 100

	local highestBid = GBAY_GetHighestBid();
	if not highestBid then
		-- This is first bid = the minimum
		return minimumBid;
	end
	
	minimumBid = 1 * (highestBid[2]);

	if CONFIG_MINBID_STRATEGY == 1 then
		minimumBid = strategy10Percent(minimumBid);
	else
		-- Fallback strategy:	
		minimumBid = strategy10Percent(minimumBid);
	end

	return floor(minimumBid);
end




--
--	Raid functions
--

function GBAY_IsInRaid(silentMode)
	local result = ( GetNumRaidMembers() > 0 )
	if not silentMode and not result then
		GuildDKP_Echo("You must be in a raid!")
	end
	return result
end

function GBAY_CanReadNotes()
	if CONFIG_USE_GUILDNOTES == 1 then
		-- Guild notes can always be read; there is no WOW setting for that.
		result = true;
	else
		result = CanViewOfficerNote();
	end	
	return result
end

function GBAY_CanWriteNotes()
	if CONFIG_USE_GUILDNOTES == 1 then
		result = CanEditPublicNote();
	else
		result = CanViewOfficerNote() and CanEditOfficerNote();
	end
	return result
end





function GBAY_GetUnitIDFromGroup(playerName)
	playerName = UCFirst(playerName);

	if GBAY_IsInRaid(false) then
		for n=1, GetNumRaidMembers(), 1 do
			if UnitName("raid"..n) == playerName then
				return "raid"..n;
			end
		end
	else
		for n=1, GetNumPartyMembers(), 1 do
			if UnitName("party"..n) == playerName then
				return "party"..n;
			end
		end				
	end
	
	return nil;	
end




--[[
--	Button handlers:
--]]

function GBAY_OnCancelBidClick(object)
	GBAY_CancelSelectedPlayerBid();
end

function GBAY_OnPauseAuctionClick(object)
	GBAY_PauseAuction();
end

function GBAY_OnFinishAuctionClick(object)
	GBAY_FinishAuction();
end

function GBAY_OnRestartAuctionClick(object)
	GBAY_RestartAuction();
end

function GBAY_OnAcceptBidClick(object)
	GBAY_AcceptSelectedPlayerBid();
end

function GBAY_OnCancelAuctionClick(object)
	GBAY_CancelAuction();
end

function GBAY_OnBidClick(object)
	local msgID = object:GetID();
	
	local bidder = getglobal(object:GetName().."Bidder"):GetText();
	if not bidder or bidder == "" then
		return;
	end	
	local bid = 1 * (getglobal(object:GetName().."Bid"):GetText());

	GBAY_ShowSelectedPlayer(bidder, bid);
end





--
--	Job Handling
--



function GBAY_AddJob( method, arg1, arg2 )
	JobQueue[table.getn(JobQueue) + 1] = { method, arg1, arg2 }
end

function GBAY_GetNextJob()
	local job
	local cnt = table.getn(JobQueue)
	
	if cnt > 0 then
		job = JobQueue[1]
		for n=2,cnt,1 do
			JobQueue[n-1] = JobQueue[n]			
		end
		JobQueue[cnt] = nil
	end

	return job
end




--
--	Guild and Raid Roster Event Handling
--
--	RaidRoster will update internal raid roster table.
--	GuildRoster will update guild roster table and check job queue
--

function GBAY_RequestUpdateGuildRoster()
	echo("In GBAY_RequestUpdateGuildRoster");
	GuildRoster()
end

function GBAY_OnGuildRosterUpdate()
	echo("In GBAY_OnGuildRosterUpdate");

	GBAY_RefreshGuildRoster();

	if GBAY_CanReadNotes() then
		if not JobIsRunning then	
			JobIsRunning = true
			
			local job = GBAY_GetNextJob()
			while job do
				job[1](job)				
				job = GBAY_GetNextJob()
			end
			
			--	Why are we doing this?
			-- if GBAY_IsInRaid(true) then
				-- GBAY_RefreshRaidRoster()
			-- end
 
			JobIsRunning = false
		end
	end
end


--[[
	Update the guild roster status cache: members and DKP.
	Used to display DKP values for non-raiding members
	(/gdclass and /gdstat)
]]
function GBAY_RefreshGuildRoster()
	echo("In GBAY_RefreshGuildRoster");

	GuildRosterTable = { }
	
	if not GBAY_CanReadNotes() then
		return;
	end

	local memberCount = GetNumGuildMembers();
	local note
	for n=1,memberCount,1 do
		local name, rank, _, _, class, _, publicnote, officernote, online = GetGuildRosterInfo(n)

		if CONFIG_USE_GUILDNOTES == 1 then		
			note = publicnote
		else
			note = officernote
		end
		
		if not note or note == "" then
			note = "<0>";
		end
		
		
		local _, _, dkp = string.find(note, "<(-?%d*)>")
		if not dkp then
			dkp = 0;
		end
		GuildRosterTable[n] = { name, (1 * dkp), class, rank, online }
	end
end


function GBAY_OnRaidRosterUpdate(event, arg1, arg2, arg3, arg4, arg5)
	RaidRosterLazyUpdate = true;
	
	-- if isInRaid(true) then
		-- synchronizeTransactionLog()
	-- else
		-- transactionLog = {}
	-- end	
end

function GBAY_GetRaidRoster()
	if RaidRosterLazyUpdate then
		GBAY_RefreshRaidRoster();
	end
	return RaidRosterTable;
end

--[[
	Re-read the raid status and namely the DKP values.
	Should be called after each roster update.
]]
function GBAY_RefreshRaidRoster()
	local playerCount = GetNumRaidMembers()
	
	if playerCount then
		RaidRosterTable = { }
		local index = 1
		local memberCount = table.getn(GuildRosterTable);
		for n=1,playerCount,1 do
			local name, _, _, _, class = GetRaidRosterInfo(n);

			for m=1,memberCount,1 do
				local info = GuildRosterTable[m]
				if name == info[1] then
					RaidRosterTable[index] = info;
					index = index + 1
				end
			end
		end
	end
	
	RaidRosterLazyUpdate = false;
	
	for n=1,table.getn(RaidRosterTable), 1 do
		local rr = RaidRosterTable[n];
		echo("RaidRosterUpdate:");
		echo(string.format("Name=%s, DKP=%d, Class=%s, Rank=%s", rr[1], rr[2], rr[3], rr[4]));
	end
end



function GBAY_OnChatMessage(event, message, sender, language, channelString)
	--("message", "sender", "language", "channelString", "target", "flags", unknown, channelNumber, "channelName", unknown, counter, "guid")
	echo(string.format("Incoming msg, channel=%s, message=%s", channelString, message));

	if sender and message then
		if channelString == GUILD_CHANNEL then
			echo("Guild message found");
			GBAY_HandleGuildChatMessage(sender, message);
		elseif channelString == RAID_CHANNEL then
			echo("Raid message found");
			GBAY_HandleRaidChatMessage(sender, message);
		else
			echo(string.format("Other channel, channel=%s, message=%s", channelString, message));
		end
	end
end




--
--	Events
--
function GBAY_OnEvent(event, arg1, arg2, arg3, arg4, arg5)
	if (event == "CHAT_MSG_GUILD") then
		GBAY_HandleGuildChatMessage(event, arg1, arg2, arg3, arg4, arg5);
	elseif (event == "CHAT_MSG_RAID" or event == "CHAT_MSG_RAID_LEADER") then
		GBAY_HandleRaidChatMessage(event, arg1, arg2, arg3, arg4, arg5);
	elseif (event == "CHAT_MSG_WHISPER") then
		GBAY_OnChatWhisper(event, arg1, arg2, arg3, arg4, arg5);
	elseif (event == "CHAT_MSG_ADDON") then
		--OnChatMsgAddon(event, arg1, arg2, arg3, arg4, arg5)
	elseif (event == "GUILD_ROSTER_UPDATE") then
		GBAY_OnGuildRosterUpdate(event, arg1, arg2, arg3, arg4, arg5)
	elseif (event == "RAID_ROSTER_UPDATE") then
		GBAY_OnRaidRosterUpdate(event, arg1, arg2, arg3, arg4, arg5)
	end
end

function GBAY_OnLoad()
	gEcho(string.format("Loot Distribution Addon version %s by %s", GetAddOnMetadata("gBay", "Version"), GetAddOnMetadata("gBay", "Author")));
    
    this:RegisterEvent("GUILD_ROSTER_UPDATE")
    this:RegisterEvent("RAID_ROSTER_UPDATE");
	this:RegisterEvent("CHAT_MSG_GUILD");
	this:RegisterEvent("CHAT_MSG_RAID");
	this:RegisterEvent("CHAT_MSG_RAID_LEADER");
    this:RegisterEvent("CHAT_MSG_WHISPER");
    this:RegisterEvent("CHAT_MSG_ADDON")
    
    
    GBAY_SetAuctionState(STATE_NONE);
      
    GBAY_RefreshRaidRoster();
	GBAY_InitializeBidElements(); 
	
	GBAY_RequestUpdateGuildRoster()
end



